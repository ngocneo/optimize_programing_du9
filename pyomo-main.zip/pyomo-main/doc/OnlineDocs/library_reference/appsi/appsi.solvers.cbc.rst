Cbc
===

.. autoclass:: pyomo.contrib.appsi.solvers.cbc.CbcConfig
  :members:
  :inherited-members:
  :undoc-members:
  :show-inheritance:

.. autoclass:: pyomo.contrib.appsi.solvers.cbc.Cbc
  :members:
  :inherited-members:
  :undoc-members:
  :show-inheritance:

Model Data Management
=====================

.. autoclass:: pyomo.dataportal.DataPortal.DataPortal
   :members:
   :special-members:

.. autoclass:: pyomo.dataportal.TableData.TableData
   :members:
   :special-members:


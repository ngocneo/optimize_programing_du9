Bilevel Programming
===================

``pyomo.bilevel`` provides extensions supporting modeling of multi-level
optimization problems.


MUMPS
=====

.. autoclass:: pyomo.contrib.pynumero.linalg.mumps_interface.MumpsCentralizedAssembledLinearSolver
  :members:
  :inherited-members:
  :show-inheritance:
  :undoc-members:

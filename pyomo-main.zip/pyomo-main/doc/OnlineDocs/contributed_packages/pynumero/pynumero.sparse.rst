PyNumero Block Linear Algebra
=============================

.. automodule:: pyomo.contrib.pynumero.sparse
  :members:

.. toctree::

   pynumero.sparse.block_vector

Projected NLP Interface
=======================

.. autoclass:: pyomo.contrib.pynumero.interfaces.nlp_projections.ProjectedNLP
  :members:
  :undoc-members:
  :inherited-members:
  :show-inheritance:

PyNumero NLP Interfaces
=======================

.. automodule:: pyomo.contrib.pynumero.interfaces
  :members:

.. toctree::

   pynumero.interfaces.nlp
   pynumero.interfaces.extended_nlp
   pynumero.interfaces.asl_nlp
   pynumero.interfaces.ampl_nlp
   pynumero.interfaces.pyomo_nlp
   pynumero.interfaces.projected_nlp
   pynumero.interfaces.external_grey_box_model
   pynumero.interfaces.pyomo_grey_box_nlp

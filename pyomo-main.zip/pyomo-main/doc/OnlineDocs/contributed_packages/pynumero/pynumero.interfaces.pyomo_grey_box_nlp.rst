Pyomo Grey Box NLP Interface
============================

.. autoclass:: pyomo.contrib.pynumero.interfaces.pyomo_nlp.PyomoGreyBoxNLP
  :members:
  :undoc-members:
  :inherited-members:
  :show-inheritance:

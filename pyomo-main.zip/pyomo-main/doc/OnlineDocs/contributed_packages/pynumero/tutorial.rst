10 Minutes to PyNumero
======================

.. toctree::

   tutorial.nlp_interfaces
   tutorial.linear_solver_interfaces
   tutorial.block_vectors_and_matrices
   tutorial.mpi_blocks

Other examples may be found at https://github.com/Pyomo/pyomo/tree/main/pyomo/contrib/pynumero/examples.

HSL MA27
========

.. autoclass:: pyomo.contrib.pynumero.linalg.ma27_interface.MA27
  :members:
  :inherited-members:
  :show-inheritance:
  :undoc-members:

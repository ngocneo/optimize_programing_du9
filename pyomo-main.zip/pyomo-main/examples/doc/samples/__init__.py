# Dummy file for nose tests

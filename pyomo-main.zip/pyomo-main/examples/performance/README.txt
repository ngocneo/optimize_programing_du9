Models that are used for testing Pyomo performance.

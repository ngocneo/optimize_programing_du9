#
# Examples for pyomo.gdp
#

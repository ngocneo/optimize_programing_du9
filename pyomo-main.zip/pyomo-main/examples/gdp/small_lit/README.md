Small GDP model examples from literature
